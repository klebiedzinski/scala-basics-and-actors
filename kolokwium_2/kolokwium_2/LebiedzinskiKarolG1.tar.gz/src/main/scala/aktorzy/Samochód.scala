import akka.actor.*
object Samochód {
  case object Dalej
}
class Samochód extends Actor with ActorLogging {
  import Samochód._
  def receive: Receive = {
    case Dalej => {
    import scala.util.Random
    val rand = new Random
    val próbaUdana = 0.15
    val reply = {
    if (rand.nextDouble() > próbaUdana) {
      val v = rand.nextInt(200)
      Some(v)
    } else {
     None
    }
    }
    sender() ! Kierowca.ReakcjaAuta(reply)
  }

      
    }
  }

