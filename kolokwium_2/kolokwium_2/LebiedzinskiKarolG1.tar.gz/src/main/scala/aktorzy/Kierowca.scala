import akka.actor.*

object Kierowca {
  case object Cyk
  case class PrzygotujAuto(warsztat: ActorRef)
  case class ReakcjaAuta(ov: Option[Int])
  case object PodajTrasę
  case class WynikNaprawy(efekt: Option[ActorRef])
}
class Kierowca extends Actor with ActorLogging {
  import Kierowca._
  def receive: Receive = {
    case PrzygotujAuto(warsztat) => {
      val moj_numer = self.path.name.split("_")(1)
      val mojeAuto = context.actorOf(Props[Samochód](), s"samochod_$moj_numer")
      
      println("moje auto jest gotowe")
      context.become(wyscig(mojeAuto,warsztat))
    }
  }
  def wyscig(mojeAuto: ActorRef,warsztat: ActorRef, s: Float = 0, v: Float = 0): Receive = {
    case Cyk =>{
      println(s"${self.path.name}: gazu!")
      mojeAuto ! Samochód.Dalej
      
    }
    case ReakcjaAuta(None) => {
      println(s"${self.path.name}: rozwaliłem! idzie do mechanika")
      warsztat ! Warsztat.Awaria(mojeAuto)
      context.become(czekamNaAuto(mojeAuto,warsztat))
    }
    case ReakcjaAuta(prędkość) => {
      
    }
    
  }
  def czekamNaAuto(mojeAuto: ActorRef,warsztat: ActorRef): Receive = {
    case WynikNaprawy(None) => {
      //kierowca konczy wyscig i zwroci aktualny dystans
    }
    case WynikNaprawy(Some(mojeAuto)) => {
      context.become(wyscig(mojeAuto,warsztat))
    }
  }
}
