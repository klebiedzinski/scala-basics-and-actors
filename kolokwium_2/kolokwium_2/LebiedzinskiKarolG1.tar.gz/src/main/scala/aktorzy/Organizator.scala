import akka.actor.*

object Organizator {
  case class UstawMaksCyk(maksCyk: Int) {
    assert(maksCyk > 0)
  }
  case object Cyk
  case class PrzejechanaTrasa(liczbaKm: Int)
  case class Init(liczbaKierowcow: Int)
}
class Organizator extends Actor with ActorLogging {
  import Organizator.*
  def receive = {
    case UstawMaksCyk(mc) =>
      println(s"liczba cyknięć do wykonania: $mc")
      context.become(ustawiamWarsztatIKierowcow(mc))
    
  }
  def ustawiamWarsztatIKierowcow(mc: Int ): Receive = {
    case Init(liczbaKierowcow) => {
      val warsztat = context.actorOf(Props[Warsztat](), "warsztat")
      val kierowcy = List.range(1,11).map(p => context.actorOf(Props[Kierowca](), s"kierowca_$p"))
      kierowcy.foreach(kierowca => kierowca ! Kierowca.PrzygotujAuto(warsztat))
      context.become(poInicjalizacji(mc,0,kierowcy,warsztat))
      println("mamy kierowcow")    
    }

  }

  def poInicjalizacji(maksCyk: Int,iloscCykniec: Int, kierowcy: List[ActorRef], warsztat: ActorRef): Receive = {
    case Cyk =>
      println("Cyk")
      warsztat ! Warsztat.Cyk
      kierowcy.foreach(kierowca => kierowca ! Kierowca.Cyk)
      context.become(poInicjalizacji(maksCyk,iloscCykniec+1,kierowcy,warsztat))
      if (iloscCykniec==maksCyk) {
        kierowcy.foreach(kierowca => kierowca ! Kierowca.PodajTrasę)
        context.become(odbieramWyniki(kierowcy, Map()))
      }
  }
  def odbieramWyniki(kierowcy: List[ActorRef], wyniki: Map[ActorRef,Int]): Receive = {
    case PrzejechanaTrasa(liczbaKm) => {
      context.become(odbieramWyniki(kierowcy,wyniki + (sender() -> liczbaKm)))
      if (wyniki.size+1 == kierowcy.size) {
        //Tworzenie rankingu (wraz z ex aequo)
        context.system.terminate()
      }
    }
  }
}

