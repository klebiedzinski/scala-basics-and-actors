import akka.actor.*
object Warsztat {
  case object Cyk
  case class Awaria(auto: ActorRef)
}
class Warsztat extends Actor with ActorLogging {
  import Warsztat._
  def receive: Receive = {
    case Awaria(auto) => {
      println(s"Warsztat: dostałem auto ${sender().path.name}")
      import scala.util.Random
      val rand = new Random
      val próbaUdana = 0.80
    if (rand.nextDouble() > próbaUdana) sender() ! Kierowca.WynikNaprawy(None)
    else {
      val czasNaprawy = rand.nextInt(6)
      context.become(naprawiamAuto(czasNaprawy,auto,sender()))
    }

    }
    case Cyk => {
      println("Warsztat: Nie mam co naprawiac")
    }
  }
  def naprawiamAuto(czasNaprawy: Int,auto: ActorRef,kierowca: ActorRef): Receive = {
    case Cyk => {
        if (czasNaprawy==0) {
          kierowca ! Kierowca.WynikNaprawy(Some(auto))
          context.become(receive)
        }
        else context.become(naprawiamAuto(czasNaprawy-1,auto,kierowca))
    }

  }
}
